
export default function App() {
  return (
    <div style={{ background: '#111827', color: '#fff', minHeight: '100vh', fontFamily: 'sans-serif', padding: '2rem' }}>
      <h1 style={{ color: '#60a5fa' }}>SEKOMAR — Marine Automation</h1>
      <p>Welcome to the official web presence of MARİNİX-100. Site is under construction.</p>
    </div>
  );
}
